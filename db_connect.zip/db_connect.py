import pyodbc

conn = pyodbc.connect("Driver={ODBC Driver 17 for SQL Server};"
                      "Server=EN4114880\SQL_MAIN;"
                      "Database=Pizza_System;"
                      "Trusted_Connection=yes;")


cursor = conn.cursor()
cursor.execute('SELECT * FROM Pizza')

for row in cursor:
    print('row = %r' % (row,))
